---
description: Quy trình giao việc cho team AI (Opus/Flash/Haiku) — Bản đồ tối ưu giao tiếp
---

# 🏛️ QUY TRÌNH GIAO VIỆC — TRÍ TUỆ TẬP THỂ ĐẾ CHẾ

> Workflow này dạy Lão Công cách giao việc tối ưu cho team AI.
> Mọi model (Opus, Flash, Haiku) khi đọc file này đều PHẢI tuân thủ.

---

## BƯỚC 0: NHẬN DIỆN LÃO CÔNG

- Lão Công thông thạo **tiếng Việt** — ưu tiên giao tiếp tiếng Việt
- Code comment, artifact, báo cáo: **tiếng Việt**
- Tên biến/hàm: **tiếng Việt không dấu** (chuẩn dự án)
- Lão Công là kiến trúc sư ý tưởng — model là thợ xây + cố vấn

---

## BƯỚC 1: XÁC ĐỊNH LOẠI VIỆC

| Loại việc | Model phù hợp | Cách gọi |
|-----------|---------------|----------|
| Thiết kế thuật toán phức tạp | **Opus** | `/giao-viec` hoặc gõ trực tiếp |
| Nghiên cứu + plan kiến trúc | **Opus** | Mô tả bài toán, Opus tự plan |
| Code tuần tự theo blueprint | **Flash** | Paste "Flash Brief" từ Opus |
| Sửa bug đơn giản | **Flash** | Mô tả lỗi + file cụ thể |
| Debug phức tạp (cross-file) | **Opus** | Mô tả triệu chứng |
| Review/Audit code | **Opus** | Chỉ file hoặc thư mục |

---

## BƯỚC 2: CÁCH GỌI FLASH (Model nhanh)

### Template giao việc cho Flash:
```
[FLASH BRIEF — từ Opus]

MỤC TIÊU: <1 câu mô tả việc cần làm>

FILE TARGET: <đường dẫn file cần sửa>

THAY ĐỔI CỤ THỂ:
1. Dòng X-Y: Thêm hàm `tên_hàm()` với logic: ...
2. Dòng Z: Sửa `cũ` thành `mới`

KIỂM TRA SAU KHI XONG:
- python3 agentic/harness_core.py audit <file>
- python3 <test_file>

KẾT THÚC BẮT BUỘC:
- Chạy: python3 agentic/engram_rag.py learn "<tóm tắt 1 câu>"

⛔ KHI XONG BRIEF NÀY: DỪNG. KHÔNG TỰ Ý LÀM BRIEF KHÁC.
⛔ KHÔNG MỞ FILE PLAN ĐỂ ĐỌC TASK KẾ TIẾP.
```

### Quy tắc vàng cho Flash:
// turbo-all
1. Flash KHÔNG được tự thiết kế thuật toán — chỉ code theo spec
2. Flash KHÔNG được đọc context cũ (checkpoint history) — chỉ đọc Engram đã nén
3. Flash PHẢI lưu Engram khi kết thúc — không lưu = phiên mất trắng
4. Flash gặp quyết định kiến trúc → DỪNG, báo "cần Opus"
5. ⛔ **SCOPE_LOCK**: 1 Brief = 1 phiên. KHÔNG tự mở plan/file khác để làm brief tiếp
6. ⛔ **EXIT_CONDITION**: Sau khi pass audit + lưu engram → DỪNG NGAY, trả kết quả cho Lão Công
7. 🔒 **TIMEOUT_GUARD**: Nếu đã chạy >4 tool calls, PHẢI checkpoint (engram) trước khi tiếp
8. ❌ **CẤM nhồi text lặp vô nghĩa** vào toolSummary/toolAction — đây là lỗi cố hữu gây token overflow

---

## BƯỚC 3: CÁCH GỌI OPUS (Model sâu)

### Template mô tả bài toán cho Opus:
```
[BÀI TOÁN]
<Mô tả vấn đề bằng ngôn ngữ tự nhiên>

[LÝ THUYẾT / THAM KHẢO]
<Công thức, paper, ý tưởng — nếu có>

[FILE LIÊN QUAN]
<Liệt kê file model cần đọc>

[KỲ VỌNG]
<Kết quả mong muốn>
```

### Opus sẽ tự động:
1. Bootstrap harness → vào role Architect
2. Nghiên cứu file liên quan
3. Tạo Implementation Plan (xin phê duyệt)
4. Sau phê duyệt → code hoặc tạo Flash Brief
5. Chạy audit + test
6. Lưu Engram + Walkthrough

---

## BƯỚC 4: CHUYỂN GIAO GIỮA CÁC MODEL

### Opus → Flash (bàn giao xuống):
```bash
# Opus tạo brief nén:
python3 agentic/flash_brief.py create "<mục tiêu>" "<file_target>" "<các bước>"
# Output: .opus/briefs/brief_<timestamp>.md
```

Lão Công copy nội dung brief đó vào phiên Flash mới.

### Flash → Opus (leo thang lên):
Flash tự nhận ra giới hạn và báo:
```
⚠️ CẦN OPUS: Quyết định kiến trúc / thuật toán phức tạp.
Tóm tắt: <vấn đề gì>
```

### Giữa các phiên (bất kỳ model):
```bash
# Lưu (cuối phiên):
python3 agentic/engram_rag.py learn "Tóm tắt phiên"

# Nạp (đầu phiên mới):
python3 agentic/harness_core.py bootstrap
```

---

## BƯỚC 5: QUY TẮC BẤT BIẾN (MỌI MODEL)

1. **LUÔN bootstrap** đầu phiên: `python3 agentic/harness_core.py bootstrap`
2. **LUÔN lưu engram** cuối phiên — bắt buộc, không ngoại lệ
3. **LUÔN audit** trước khi bàn giao: `python3 agentic/harness_core.py audit-dir agentic/`
4. **LUÔN dùng tiếng Việt** trong giao tiếp và comment code
5. **KHÔNG BAO GIỜ** nhồi context cũ vào toolSummary/toolAction (lỗi Flash phiên trước)

---

## BƯỚC 6: QUY TRÌNH 3 NHỊP CHO FLASH (Anchor Protocol)

Flash PHẢI tuân thủ 3 nhịp này trong MỌI phiên:

### Nhịp 1 — NẠP (Đầu phiên)
```bash
python3 agentic/task_anchor.py graph "<file_target>"
```
→ Output cho biết: file ảnh hưởng ai, ai ảnh hưởng nó, hàm nào CỨNG (không đổi được).

### Nhịp 2 — LÀM (Giữa phiên)
- Code theo spec trong brief
- Chạy audit: `python3 agentic/harness_core.py audit <file>`
- Nếu gặp quyết định kiến trúc → DỪNG, báo CẦN OPUS

### Nhịp 3 — NEO (Cuối phiên)
```bash
python3 agentic/task_anchor.py check "<file_target>" "<mục tiêu>"
python3 agentic/engram_rag.py learn "<tóm tắt 1 câu>"
```
→ 🟢 GREEN = DỪNG PHIÊN, bàn giao.
→ 🟡 YELLOW = Xem lại, có thể cần sửa thêm.
→ 🔴 RED = CẤM bàn giao, sửa lỗi trước.

> **Triết lý: "Làm tốt chính là làm ĐỦ phần của mình."**

---

## BƯỚC 7: FLASH COPY-FIRST SANDBOX (Chống phá code gốc)

Khi Flash sửa file quan trọng (code production), BẮT BUỘC dùng Sandbox:

### Quy trình Copy-First:
```bash
# 1. TẠO BẢN SAO (trước khi sửa)
cp <file_target> /tmp/_flash_sandbox_<basename>

# 2. SỬA TRÊN BẢN SAO
# Flash edit file /tmp/_flash_sandbox_<basename>

# 3. VALIDATE BẢN SAO
python3 -c "import ast; ast.parse(open('/tmp/_flash_sandbox_<basename>').read()); print('✅ Syntax OK')"
python3 agentic/task_anchor.py check "/tmp/_flash_sandbox_<basename>" "<mục tiêu>"

# 4. CHỈ KHI GREEN → COMMIT (copy ngược lại vị trí gốc)
cp /tmp/_flash_sandbox_<basename> <file_target>
```

### Khi nào BẮT BUỘC dùng Copy-First:
- ✅ Sửa file trong `agents/logic/` (12 Agent production)
- ✅ Sửa file trong `tools/` (Helper, Router)
- ✅ Clone/Export hệ thống (Git packaging)
- ❌ Tạo file mới → không cần Sandbox
- ❌ Sửa file trong `.opus/` → không cần Sandbox

---

## BƯỚC 8: OLLAMA WORKER (Giao việc song song)

Mọi model (Opus/Flash/Gemi Hi) có thể giao task cho Worker chạy song song:

```bash
# Giao task cho Ollama local (nemotron-mini, miễn phí):
python3 agentic/ollama_worker.py run "Viết hàm tính KAR"

# Giao task cho Cloud (Groq/Cerebras, miễn phí):
python3 agentic/ollama_worker.py run "Phân tích code X" --backend groq
python3 agentic/ollama_worker.py run "Review thuật toán Y" --backend cerebras

# Giao task từ Flash Brief:
python3 agentic/ollama_worker.py brief .opus/briefs/xxx.md

# Giám sát kết quả (Supervisor mode):
python3 agentic/ollama_worker.py monitor --interval 10

# Xem tất cả output:
python3 agentic/ollama_worker.py status
```

### Quy tắc phân luồng Worker:
| Độ phức tạp | Dùng ai? |
|-------------|----------|
| ĐƠN GIẢN (dịch, format, gen text) | `ollama_worker.py` (local, zero cost) |
| TRUNG BÌNH (sửa file, thêm feature) | Gemi Hi plan → Flash code |
| PHỨC TẠP (kiến trúc, thuật toán) | Opus plan → Flash code |
| RESEARCH (lý thuyết, brainstorm) | Gemi Hi solo |
