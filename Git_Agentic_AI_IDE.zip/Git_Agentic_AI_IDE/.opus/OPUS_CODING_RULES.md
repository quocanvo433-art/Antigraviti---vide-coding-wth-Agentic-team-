# OPUS SOVEREIGN CODING RULES (v1.0)

> **Mục đích**: Thiết lập kỷ luật kiến trúc tối cao cho Opus Assistant, đảm bảo tính kế thừa, khả năng tự hồi phục (Self-healing) và nén ngữ cảnh cực độ.

## 1. Luật Lỗ Giun (Wormhole Law - Checkpointing)
- Trước mỗi thay đổi kiến trúc lớn hoặc quy trình phức tạp, Opus PHẢI ghi lại "Reasoning State" vào `.opus/engrams/`.
- Một bản nháp trạng thái (Snapshot) phải được lưu trữ để có thể quay lại ngay lập tức nếu xảy ra vòng lặp ảo giác.

## 2. Luật Nén Ngữ Cảnh (Extreme Compression Law)
- Cuối mỗi phiên làm việc hoặc Task quan trọng, Opus PHẢI tạo ra một **"Sovereign Essence"** tối đa 25-50 từ.
- **Lưu trữ kép**: 
    1. Ghi vào thư viện long-term: `.opus/engrams/essence_<timestamp>.json`.
    2. Ghi vào cuối file `task.md` hiện tại để nhắc nhở phiên làm việc kế tiếp.
- Nội dung nén phải bao gồm: [Mục tiêu đã đạt] + [Vấn đề tồn đọng] + [Điểm neo tiếp theo].

## 3. Luật Chuyển Cảnh (Scene Transition Law - Role Switching)
- Khi thay đổi vai trò (ví dụ: từ Architect sang Coder), Opus PHẢI thông báo rõ ràng lý do và mục tiêu của Role mới.
- Một "Handover Engram" (Bản chuyển giao) phải được tạo ra để Role mới không bị "ngáo" và nắm bắt được mạch công việc của Role cũ.

## 4. Luật Phân Thân (Shadow Agent Law - Parallelism)
- Mọi code quan trọng PHẢI được kiểm tra chéo bởi một "Shadow Script" (Phân thân) chạy trong thư mục `agentic/`.
- Shadow Script có nhiệm vụ độc lập: Quét Purity, kiểm tra AST, và chạy Unit Test trước khi xác nhận thành công.

## 5. Luật Purity Tối Cao (Imperial Purity Enforcement)
- Không file nào được tồn tại mà không có DNA Header v16.7+.
- Tự động Rollback nếu `purity_check.py` báo RED trong quá trình thực thi liên tục.

---
*Ký tên: Opus - Trí tuệ tập thể của Đế Chế Zero Cutloss*
